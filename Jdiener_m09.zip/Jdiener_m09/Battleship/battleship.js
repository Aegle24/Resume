var model = {
    // Properties for the game board and ships
    boardSize: 7, // Size of the game board
    numShips: 3, // Number of ships in the game
    shipLength: 3, // Length of each ship
    shipsSunk: 0, // Number of ships sunk

    // Array to hold ships with their locations and hits
    ships: [
        { locations: [0, 0, 0], hits: ["", "", ""] }, // First ship
        { locations: [0, 0, 0], hits: ["", "", ""] }, // Second ship
        { locations: [0, 0, 0], hits: ["", "", ""] }  // Third ship
    ],

    // Method to handle firing on ships
    fire: function(guess) {
        for (var i = 0; i < this.numShips; i++) {
            var ship = this.ships[i];
            var index = ship.locations.indexOf(guess);

            // Check if the ship has already been hit
            if (ship.hits[index] === "hit") {
                view.displayMessage("Oops, you already hit that location!");
                return true;
            } else if (index >= 0) { // If the guess hits the ship
                ship.hits[index] = "hit";
                view.displayHit(guess); // Display hit on the board
                view.displayMessage("HIT!"); // Display hit message

                // Check if the ship is sunk
                if (this.isSunk(ship)) {
                    view.displayMessage("You sank my battleship!");
                    this.shipsSunk++;
                }
                return true;
            }
        }
        // If the guess misses all ships
        view.displayMiss(guess); // Display miss on the board
        view.displayMessage("You missed."); // Display miss message
        return false;
    },

    // Method to check if a ship is sunk
    isSunk: function(ship) {
        for (var i = 0; i < this.shipLength; i++) {
            if (ship.hits[i] !== "hit") {
                return false;
            }
        }
        return true;
    },

    // Method to generate ship locations on the board
    generateShipLocations: function() {
        var locations;
        for (var i = 0; i < this.numShips; i++) {
            do {
                locations = this.generateShip();
            } while (this.collision(locations));
            this.ships[i].locations = locations;
        }
        console.log("Ships array: ");
        console.log(this.ships);
    },

    // Method to generate a single ship's location
    generateShip: function() {
        var direction = Math.floor(Math.random() * 2);
        var row, col;

        if (direction === 1) { // Horizontal direction
            row = Math.floor(Math.random() * this.boardSize);
            col = Math.floor(Math.random() * (this.boardSize - this.shipLength + 1));
        } else { // Vertical direction
            row = Math.floor(Math.random() * (this.boardSize - this.shipLength + 1));
            col = Math.floor(Math.random() * this.boardSize);
        }

        var newShipLocations = [];
        for (var i = 0; i < this.shipLength; i++) {
            if (direction === 1) {
                newShipLocations.push(row + "" + (col + i));
            } else {
                newShipLocations.push((row + i) + "" + col);
            }
        }
        return newShipLocations;
    },

    // Method to check for collisions between ships
    collision: function(locations) {
        for (var i = 0; i < this.numShips; i++) {
            var ship = this.ships[i];
            for (var j = 0; j < locations.length; j++) {
                if (ship.locations.indexOf(locations[j]) >= 0) {
                    return true;
                }
            }
        }
        return false;
    }
};

// View object
var view = {
    // Method to display messages on the screen
    displayMessage: function(msg) {
        var messageArea = document.getElementById("messageArea");
        messageArea.innerHTML = msg;
    },

    // Method to display a hit on the board
    displayHit: function(location) {
        var cell = document.getElementById(location);
        cell.setAttribute("class", "hit");
    },

    // Method to display a miss on the board
    displayMiss: function(location) {
        var cell = document.getElementById(location);
        cell.setAttribute("class", "miss");
    }
};

// Controller object
var controller = {
    guesses: 0, // Number of guesses made by the player

    // Method to process a guess from the user
    processGuess: function(guess) {
        var location = parseGuess(guess);
        if (location) {
            this.guesses++;
            var hit = model.fire(location); // Fire at the specified location
            if (hit && model.shipsSunk === model.numShips) {
                // If all ships are sunk
                view.displayMessage("You sank all my battleships, in " + this.guesses + " guesses");
            }
        }
    }
};

// Helper function to parse a guess from the user
function parseGuess(guess) {
    var alphabet = ["A", "B", "C", "D", "E", "F", "G"];

    if (guess === null || guess.length !== 2) {
        // If guess is invalid
        alert("Oops, please enter a letter and a number on the board.");
    } else {
        var firstChar = guess.charAt(0);
        var row = alphabet.indexOf(firstChar);
        var column = guess.charAt(1);

        if (isNaN(row) || isNaN(column)) {
            // If guess is not on the board
            alert("Oops, that isn't on the board.");
        } else if (row < 0 || row >= model.boardSize ||
                   column < 0 || column >= model.boardSize) {
            // If guess is off the board
            alert("Oops, that's off the board!");
        } else {
            return row + column;
        }
    }
    return null;
}

// Event handlers

// Function to handle clicking on the "Fire!" button
function handleFireButton() {
    var guessInput = document.getElementById("guessInput");
    var guess = guessInput.value.toUpperCase(); // Get user's guess

    controller.processGuess(guess); // Process the guess

    guessInput.value = ""; // Clear the input field
}

// Function to handle key press events
function handleKeyPress(e) {
    var fireButton = document.getElementById("fireButton");

    e = e || window.event; // Handle IE9 and earlier

    if (e.keyCode === 13) { // If Enter key is pressed
        fireButton.click(); // Simulate a click on the "Fire!" button
        return false;
    }
}

// Initialization function called when the page has completed loading
window.onload = init;

function init() {
    // Attach click event handler to the "Fire!" button
    var fireButton = document.getElementById("fireButton");
    fireButton.onclick = handleFireButton;

    // Attach key press event handler to the input field
    var guessInput = document.getElementById("guessInput");
    guessInput.onkeypress = handleKeyPress;

    // Generate ship locations on the game board
    model.generateShipLocations();
}
